import asyncio
import json
import subprocess
from websockets import serve, WebSocketServerProtocol
from xmlrpc.server import SimpleXMLRPCServer
import threading
import pathlib

# In-memory state
clients = {}  # ws -> {"username": str, "token": str}
username_to_ws = {}  # username -> ws

# Global asyncio loop reference (used by RPC thread)
main_loop: asyncio.AbstractEventLoop | None = None

# Project root (one level above exp2/)
PROJECT_ROOT = pathlib.Path(__file__).resolve().parent.parent

# ---- RMI Login via Java bridge ----
def rmi_login(username: str, password: str) -> str | None:
    try:
        out = subprocess.check_output(
            ["java", "exp2.AuthClient", username, password],
            cwd=PROJECT_ROOT,  # dynamically resolved root
            stderr=subprocess.STDOUT,
            timeout=5,
            text=True,
        ).strip()
        if out in ("AUTH_FAIL", "AUTH_ERROR"):
            return None
        return out
    except Exception as e:
        print("AuthClient failed:", e)
        return None

# ---- Broadcast helper ----
async def broadcast(payload: dict, exclude: WebSocketServerProtocol | None = None):
    dead = []
    for ws in list(clients.keys()):
        if ws is exclude:
            continue
        try:
            await ws.send(json.dumps(payload))
        except Exception:
            dead.append(ws)
    for ws in dead:
        try:
            u = clients[ws]["username"]
            del username_to_ws[u]
        except Exception:
            pass
        clients.pop(ws, None)

# ---- WebSocket handlers ----
async def handle_ws(ws: WebSocketServerProtocol):
    try:
        hello = await asyncio.wait_for(ws.recv(), timeout=15)
        msg = json.loads(hello)
        if msg.get("type") != "login":
            await ws.send(json.dumps({"type": "error", "error": "expected login"}))
            return

        username = str(msg.get("username", "")).strip()
        password = str(msg.get("password", ""))
        token = rmi_login(username, password)
        if not token:
            await ws.send(json.dumps({"type": "login", "status": "fail", "reason": "invalid"}))
            return

        # Register
        clients[ws] = {"username": username, "token": token}
        username_to_ws[username] = ws
        await ws.send(json.dumps({"type": "login", "status": "ok", "token": token}))
        await broadcast({"type": "system", "message": f"🔔 {username} joined"}, exclude=ws)

        # Main loop for chat messages
        async for raw in ws:
            try:
                data = json.loads(raw)
            except Exception:
                await ws.send(json.dumps({"type": "error", "error": "bad_json"}))
                continue

            if data.get("type") == "chat":
                text = str(data.get("message", ""))
                await broadcast({"type": "chat", "from": username, "message": text})
            elif data.get("type") == "pm":
                to = data.get("to")
                text = str(data.get("message", ""))
                target = username_to_ws.get(to)
                if target:
                    await target.send(json.dumps({"type": "pm", "from": username, "message": text}))
                else:
                    await ws.send(json.dumps({"type": "error", "error": "user_not_online"}))
            else:
                await ws.send(json.dumps({"type": "error", "error": "unknown_type"}))

    except Exception:
        pass
    finally:
        if ws in clients:
            username = clients[ws]["username"]
            clients.pop(ws, None)
            username_to_ws.pop(username, None)
            await broadcast({"type": "system", "message": f"👋 {username} left"})

# ---- XML-RPC Admin server ----
def rpc_list_users():
    return sorted([meta["username"] for meta in clients.values()])

def rpc_announce(message):
    asyncio.run_coroutine_threadsafe(
        broadcast({"type": "system", "message": f"[ADMIN] {message}"}), main_loop
    )
    return True

def rpc_kick(username):
    ws = username_to_ws.get(username)
    if not ws:
        return False
    asyncio.run_coroutine_threadsafe(ws.close(code=4000, reason="kicked"), main_loop)
    return True

def start_rpc_server():
    srv = SimpleXMLRPCServer(("0.0.0.0", 8000), allow_none=True, logRequests=False)
    srv.register_function(rpc_list_users, "list_users")
    srv.register_function(rpc_announce, "announce")
    srv.register_function(rpc_kick, "kick")
    print("XML-RPC admin listening on http://localhost:8000")
    srv.serve_forever()

async def main_ws():
    async with serve(handle_ws, "0.0.0.0", 8765):
        print("WebSocket chat on ws://localhost:8765")
        await asyncio.Future()  # run forever

if __name__ == "__main__":
    # start RPC in background thread
    t = threading.Thread(target=start_rpc_server, daemon=True)
    t.start()

    # run WS loop with explicit loop reference
    main_loop = asyncio.new_event_loop()
    asyncio.set_event_loop(main_loop)
    main_loop.run_until_complete(main_ws())
